package com.app.web.dao;

import com.app.web.model.Usuario;

public interface UsuarioDao {
	
	public void guardarUsuario(Usuario usuario);

}
